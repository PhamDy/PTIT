/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package danhsachmathang;

/**
 *
 * @author ADMIN
 */
import java.util.*;
public class Main {
    public static void main(String[] args) {
        Scanner in= new Scanner (System.in);
        ArrayList<MatHang> arr = new ArrayList<>();
        int t= Integer.parseInt(in.nextLine());
        for (int i=0; i<t; i++){
            arr.add(new MatHang(i+1, in.nextLine(), in.nextLine(), Integer.parseInt(in.nextLine()),Integer.parseInt(in.nextLine())));
        }
        Collections.sort(arr);
        for (MatHang i : arr){
            System.out.println(i);
        }
    }
}
