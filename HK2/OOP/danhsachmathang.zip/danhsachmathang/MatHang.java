/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package danhsachmathang;

/**
 *
 * @author ADMIN
 */
public class MatHang implements Comparable<MatHang>{
        private String ma, name, donvi;
        private int mua, ban, loinhuan;

        public MatHang(int stt , String name, String donvi, int mua, int ban) {
            this.ma = String.format("MH%03d", stt);
            this.name = name;
            this.donvi = donvi;
            this.mua = mua;
            this.ban = ban;
            loinhuan= ban - mua;
        }
        
        @Override
        public String toString() {
            return this.ma +" "+ this.name +" "+ this.donvi +" " + this.mua+" "+ this.ban +" "+ this.loinhuan;
            
        }
        @Override
        public int compareTo(MatHang other) {
            if (this.loinhuan == other.loinhuan){
                return this.ma.compareTo(other.ma);
            } 
            return other.loinhuan - this.loinhuan;
        }
}
